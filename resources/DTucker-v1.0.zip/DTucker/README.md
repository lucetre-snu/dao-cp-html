# D-TUCKER: Fast and Memory-Efficient Tucker Decomposition for Dense Tensor
This is a code for "D-TUCKER: Fast and Memory-Efficient Tucker Decomposition for Dense Tensor", submitted to VLDB 2020.
Authors: Jun-Gi Jang (elnino9158@gmail.com), Seoul National University
          U Kang (ukang@snu.ac.kr), Seoul National University
Version: 1.0
Date: 1 Aug 2019
Main Contact: Jun-Gi Jang

## Code Information
All codes are written by MATLAB 2019.
This repository contains the code for D-Tucker, a fast and memory-efficient method for
Tucker decomposition on large dense tensors. Given a large dense tensor, D-Tucker factorizes a given tensor into orthogonal factor matrices and a core tensor.

- The code of D-Tucker is in `src` directory.
- The libraries used for D-Tucker are in `library` directory.
- The demo code of D-Tucker is in `demo` directory.

## How to run for sample data
For simple test, we generate 4 random tensor data of the same size as real-world tensors used in the experiment.
We provide demo scripts for our method D-Tucker.
First, you run the matlab program, and then you should add paths into MATLAB environment. Please type the following command in MATLAB:
    `addPaths`

Then, type the following command to run the demo:
    `run demo/run_demo_dtucker_sample`

## How to run for real-world data
We used 4 real-world tensor datasets in the experiment.
We provide demo scripts for our method D-Tucker.
You can download datasets in the following:
 <https://drive.google.com/open?id=1Tu_ghi9n5QM0NRwXuFE8Mn9i83VC2WCn>

After downlonad, you extract the tgz file, and move the extracted folder to dtucker folder (home folder of this repository).

We provide demo scripts for our method D-Tucker.
First, you run the matlab program, and then you should add paths into MATLAB environment. Please type the following command in MATLAB:
    `addPaths`

Then, type the following command to run the demo:
    `run demo/run_demo_dtucker_realworld`

## Licence
This software may be used only for research evaluation purposes.
For other purposes (e.g., commercial), please contact the authors.
