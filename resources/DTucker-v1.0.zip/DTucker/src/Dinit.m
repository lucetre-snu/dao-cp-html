function Ainit = Dinit(decompU, decompS, decompV, dims, R)

    order = size(dims, 2);
    Ainit = cell(1,order);

    for n = 3:order
        Ainit{n} = randn([dims(n) R(n)]);
    end
    
    column_length = prod(dims(3:end));
    USigma_cell = cellfun(@(a,b) a*diag(b), decompU, decompS, 'UniformOutput', 0);

    USigma = cell2mat(reshape(USigma_cell, [1, column_length]));
    [U1, S1, V1] = rSVD(USigma, R(1), 2);
    U1 = U1(:, 1:R(1));
    
    VSigma_cell = cellfun(@(a) a.'*U1, USigma_cell, 'UniformOutput', 0);
    VSigma_cell = cellfun(@(a,b) a*b, decompV, VSigma_cell, 'UniformOutput', 0);

    VSigma = cell2mat(reshape(VSigma_cell, [1, column_length]));
    size(VSigma)

    [U2, S2, V2] = rSVD(VSigma, R(2), 2);
    U2 = U2(:, 1:R(2));

    Ainit{1} = U1;
    Ainit{2} = U2;

    y12 = cellfun(@(a) a.'*U2, VSigma_cell, 'UniformOutput', 0);
    y12 = cell2mat(reshape(y12, [1, column_length]));
    size(y12)

    y12_dims = dims;
    y12_dims(1) = R(1);
    y12_dims(2) = R(2);
    y12 = tensor(tenmat(y12, 2, [3:order, 1], y12_dims));
    size(y12)
   
    for n = 3:order
        y12_tenmat = double(tenmat(y12, n));
        [Un, Sn, Vn] = rSVD(y12_tenmat, R(n), 2);
        Un = Un(:, 1:R(n));
        Ainit{n} = Un;
        y12_tenmat = Un.'*y12_tenmat;
        y12_dims(n) = R(n);
        y12 = tensor(tenmat(y12_tenmat, n, [(n+1):order, 1:(n-1)], y12_dims)); 
    end
%    whos
%    memcheck = whos;
%    memcheck = struct2cell(memcheck);
%    memcheck = cell2mat(memcheck(3,:));
%    sum(memcheck)
end


    



