function [Aupdate, core] = Dupdate(decompU, decompS, decompV, Aprev, dims)
    Aprev = cellfun(@transpose, Aprev, 'un', 0);
    order = size(Aprev, 2);
    Aupdate = cell([1 order]);
    % first mode
    y1_inter = cellfun(@(x) Aprev{2}*x, decompV, 'un', 0);
%    y1_inter = cell(1, size(decompV, 2));
%    size(decompV)
%    for l = 1:size(decompV, 2)
%        y1_inter{l} = Aprev{2}*decompV{l};        
%    end

    y1_tmp = y1_inter;
    
    y1 = cellfun(@(x,y,z) x*diag(y)*z.', decompU, decompS, y1_inter, 'un', 0);
%    for l = 1:size(decompU, 2)
%        y1{l} = decompU{l}*diag(decompS{l})*y1_inter{l}.';
%    end
    y1 = reshape(y1, [1, prod(dims(3:end))]);
    y1 = cell2mat(y1);
    inter_dims = dims;
    inter_dims(2) = size(Aprev{2}, 1);
    y1 = tensor(y1, inter_dims);
    y1 = ttm(y1, Aprev(3:order), [3:order]);
    y1 = double(tenmat(y1, 1));
    [U1, S1, V1] = rSVDbasic(y1, size(Aprev{1}, 1), 2);
    Aupdate{1} = U1;

    % second mode
    y2_inter = cellfun(@(x) Aupdate{1}.'*x, decompU, 'un', 0);
%    y2_inter = cell(1, size(decompU, 2));
%    for l = 1:size(decompU, 2)
%        y2_inter{l} = Aupdate{1}.'*decompU{l}
%    end
    y2_tmp = y2_inter;
    y2 = cellfun(@(x,y,z) x*diag(y)*z.', y2_inter, decompS, decompV, 'un', 0);
%    for l = 1:size(decompU, 2)
%        y2_inter{l}*diag(decompS{l})*decompV{l}.';
%    end
    y2 = reshape(y2, [1, prod(dims(3:end))]);
    y2 = cell2mat(y2);
    inter_dims = dims;
    inter_dims(1) = size(Aprev{1}, 1);
    y2 = tensor(y2, inter_dims);
    y2 = ttm(y2, Aprev(3:order), [3:order]);
    y2 = double(tenmat(y2, 2));
    [U2, S2, V2] = rSVDbasic(y2, size(Aprev{2}, 1), 2);
    Aupdate{2} = U2;


    yi_inter = cellfun(@(x) Aupdate{2}.'*x, decompV, 'un', 0);
    yi_inter = cellfun(@(x,y,z) x*diag(y)*z.', y2_inter, decompS, yi_inter, 'un', 0); 
%    yi_inter = cell(1, size(decompV,2));
%    for l = 1:size(decompV, 2)
%        yi_inter{l} = Aupdate{2}.'*decompV{l};
%    end
%    for l = 1:size(decompV, 2)
%        y2_inter{l} = y2_inter{l}*diag(decompS{l})*yi_inter{l}.';
%    end
%    yi_inter = reshape(yi_inter, [1, prod(dims(3:end))]);
    
    inter_dims = dims;
    inter_dims(1) = size(Aprev{1}, 1);
    inter_dims(2) = size(Aprev{2}, 1);

    yi_inter = cell2mat(yi_inter);
    yi_inter = tensor(yi_inter, inter_dims);
    core = yi_inter;
    % rest modes
    for mode=3:order
        yi_mode = yi_inter;
        if ~isempty([3:mode-1])
            yi_mode = ttm(yi_mode, Aprev(3:mode-1), [3:mode-1]);
        end
        if ~isempty([mode+1:order])
            yi_mode = ttm(yi_mode, Aprev(mode+1:end), [mode+1:order]);
        end
        yi_mode = double(tenmat(yi_mode, mode));
        [Ui, Si, Vi] = rSVDbasic(yi_mode, size(Aprev{mode}, 1), 2);
        Aupdate{mode} = Ui;
    end

    % core tensor
    core = ttm(core, cellfun(@transpose, Aupdate(3:order),'un', 0), [3:order]);


%    memcheck = whos;
%    memcheck = struct2cell(memcheck);
%    memcheck = cell2mat(memcheck(3,:));
%    sum(memcheck)

end

