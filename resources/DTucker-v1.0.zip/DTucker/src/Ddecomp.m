function [decompU, decompS, decompV] = Ddecomp(X, rank)
    dims = size(X)
    transform = dims(2)*ones(1, prod(dims(3:end)));
    X = double(tenmat(X, 1));
    decompU = cell(1, prod(dims(3:end)));
    decompS = cell(1, prod(dims(3:end)));
    decompV = cell(1, prod(dims(3:end)));
%    tic;
%    Y = mat2cell(X, dims(1), transform);
%    toc;
%    X = Y;
    
%    if size(dims, 2) == 3
%        X = reshape(X, [1 dims(3)]);
%    else
%        X = reshape(X, dims(3:end));
%    end

    for i=1:prod(dims(3:end))
        [u,s,v] = rSVD(X(:, ((i-1)*dims(2)+1):(i*dims(2))), rank);
        decompU{i} = u;
        decompS{i} = s;
        decompV{i} = v;
    end

%    [decompU, decompS, decompV] = cellfun(@(x) rSVDbasic(x, rank, 1), X, 'un', 0);

end
