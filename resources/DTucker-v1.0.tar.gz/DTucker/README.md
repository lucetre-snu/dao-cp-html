# D-TUCKER: Fast and Memory-Efficient Tucker Decomposition for Dense Tensors
This is a code for "D-TUCKER: Fast and Memory-Efficient Tucker Decomposition for Dense Tensors", submitted to ICDE 2020.
Authors: Jun-Gi Jang (elnino9158@gmail.com), Seoul National University
          U Kang (ukang@snu.ac.kr), Seoul National University
Version: 1.1
Date: 15 Oct 2019
Main Contact: Jun-Gi Jang

## Code Information
All codes are written by MATLAB 2019.
This repository contains the code for D-Tucker, a fast and memory-efficient method for
Tucker decomposition on large dense tensors. Given a large dense tensor, D-Tucker factorizes a given tensor into orthogonal factor matrices and a core tensor.

- The code of D-Tucker is in `src` directory.
- The libraries used for D-Tucker are in `library` directory.
- The demo code of D-Tucker is in `demo` directory.

## Library
For running our method, we use the following libraries.
If you use our method, please refer to the following, too.
We use the following libraries:
 - `Tensor Toolbox v3.0`
 > * Reference: B. W. Bader, T. G. Kolda et al., “Matlab tensor toolbox version 3.0-dev,” Available online, Oct. 2017. [Online]. Available: <https://www.tensortoolbox.org>

 - `CountSketch operation`: implemented by O. A. Malik and S. Becker.
 > * Reference: O. A. Malik and S. Becker, “Low-rank tucker decomposition of large
tensors using tensorsketch,” in NeurIPS, 2018, pp. 10 117–10 127 [Online]. Available: <https://github.com/OsmanMalik/tucker-tensorsketch>

 - `Randomized SVD`
 - We implemented randomized svd described in the following reference.
 > * Reference: F. Woolfe, E. Liberty, V. Rokhlin, and M. Tygert, “A fast randomized algorithm for the approximation of matrices,” Applied and Computational Harmonic Analysis, vol. 25, no. 3, pp. 335–366, 2008.


## How to run for sample data
For simple test, we generate 4 random tensor data of the same size as real-world tensors used in the experiment.
We provide demo scripts for our method D-Tucker.

First, you run MATLAB, and type following commands in MATLAB.

Before you run our proposed method, you run the file `compile_countSketch.m` for compiling C file of countSketch operation inside library/Randomized/countSketch directory.

You can also compile C file of countSketch using 'mex' command (mex countSketch.c).

Then, you should add paths into MATLAB environment. Please type the following command in MATLAB:
    `addPaths`

Then, type the following command to run the demo for the synthetic data:
    `run demo/run_demo_dtucker_sample`

## How to run for real-world data
We used 4 real-world tensor datasets in the experiment.
We provide demo scripts for our method D-Tucker.
You can download datasets in our hompage:
 datalab.snu.ac.kr:/dtucker

After downlonad, you extract the tar.gz file, and move the extracted folder to data folder of dtucker
(Or you can change data paths in the run_demo_dtucker_realworld.m file).

You run MATLAB, and type following commands in MATLAB.

Before you run our proposed method, you run the file `compile_countSketch.m` for compiling C file of countSketch operation inside library/Randomized/countSketch directory.

You can also compile C file of countSketch using 'mex' command (mex countSketch.c).

Then, you should add paths into MATLAB environment. Please type the following command in MATLAB:
    `addPaths`

We provide demo scripts to run our method D-Tucker for real-world datasets.
Then, type the following command to run the demo:
    `run demo/run_demo_dtucker_realworld`

## Licence
This software may be used only for research evaluation purposes.
For other purposes (e.g., commercial), please contact the authors.
