% rSVD: Given a matrix, decompose the matrix using 
% using randomized singular value decomposition (svd)
% 
% Implement randomzied SVD described in 
% F. Woolfe, E. Liberty, V. Rokhlin, and M. Tygert, “A fast randomized algorithm
% for the approximation of matrices,” Applied and Computational
% Harmonic Analysis, vol. 25, no. 3, pp. 335–366, 2008. 
%
% Parameter
% A: input matrix
% rank: target rank for svd
%
% Return
% U: left singular vector matrix
% S: the set of singular value matrix
% V: the set of right singular vector matrix
%

function [U, S, V]=rSVD(A, r)

[m,n] = size(A);

k = 4*r;
l = 10*r;

s1 = round(rand(n, 1))*2 -1;
h1int64 = int64(randi(k, n, 1));
Y_til = countSketch(A, h1int64, k, s1, 1);
Y_til = Y_til';
s2 = round(rand(m, 1))*2 -1;
h2int64 = int64(randi(l, m, 1));

Y = countSketch(A, h2int64, l, s2, 0);

[Q, Z] = qr(Y', 0);
Q = Q(:,1:k);
Z = Z(1:k, :);
[P, Z_til] = qr(Y_til',0);
%W = psi*P;
W = countSketch(P', h2int64, l, s2, 1);
W = W';
B = Y*Q;
X = linsolve(W,B);
[u,s,v] = svd(X,'econ');

U = P*u(:,1:r);
S = diag(s(1:r, 1:r));
V = Q*v(:,1:r);

end 
