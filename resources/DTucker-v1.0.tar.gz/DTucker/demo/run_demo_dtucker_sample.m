LASTN = maxNumCompThreads(1);

tol = 1e-4; % Tolerance
maxiters = 50; % Maximum number of iterations
use_init = 1;

fprintf('Generate dense tensor...\n');

R_true = [10,10,5]; % True tensor rank
I = [360, 21764, 9]; % Tensor size
noise_level = 1e-4; % Amount of noise added to nonzero elements

%% Generate random dense tensor

G_true = tensor(randn(R_true));
A_true = cell(length(R_true),1);
for k = 1:length(R_true)
    A_true{k} = randn(I(k),R_true(k));
    [Qfac, ~] = qr(A_true{k}, 0);
    A_true{k} = Qfac;
end
X1 = tensor(ttensor(G_true, A_true)) + noise_level*randn(I);
fprintf('Generating data is done\n');

[core1, factors1] = DTucker(X1, [10 10 5], tol, maxiters, use_init);
Xr = ttm(tensor(core1), factors1);
our_error = norm(X1-Xr)^2/norm(tensor(X1))^2;
fprintf(' Error is  %4f\n', our_error);

fprintf('Generate dense tensor...\n');

R_true = [10,10,5]; % True tensor rank
I = [4555, 14351, 5]; % Tensor size
noise_level = 1e-4; % Amount of noise added to nonzero elements

%% Generate random dense tensor

G_true = tensor(randn(R_true));
A_true = cell(length(R_true),1);
for k = 1:length(R_true)
    A_true{k} = randn(I(k),R_true(k));
    [Qfac, ~] = qr(A_true{k}, 0);
    A_true{k} = Qfac;
end
X2 = tensor(ttensor(G_true, A_true)) + noise_level*randn(I);
fprintf('Generating data is done\n');

[core2, factors2] = DTucker(X2, [10 10 5], tol, maxiters, use_init);

Xr = ttm(tensor(core2), factors2);
our_error = norm(X2-Xr)^2/norm(tensor(X2))^2;
fprintf(' Error is  %4f\n', our_error);

fprintf('Generate dense tensor...\n');

R_true = [10,10,5]; % True tensor rank
I = [30648, 376, 6]; % Tensor size
noise_level = 1e-4; % Amount of noise added to nonzero elements

%% Generate random dense tensor

G_true = tensor(randn(R_true));
A_true = cell(length(R_true),1);
for k = 1:length(R_true)
    A_true{k} = randn(I(k),R_true(k));
    [Qfac, ~] = qr(A_true{k}, 0);
    A_true{k} = Qfac;
end
X3 = tensor(ttensor(G_true, A_true)) + noise_level*randn(I);

fprintf('Generating data is done\n');

[core3, factors3] = DTucker(X3, [10 10 5], tol, maxiters, use_init);

Xr = ttm(tensor(core3), factors3);
our_error = norm(X3-Xr)^2/norm(tensor(X3))^2;
fprintf(' Error is  %4f\n', our_error);

fprintf('Generate dense tensor...\n');

R_true = [10,10,10,5]; % True tensor rank
I = [1021, 1340, 33, 8]; % Tensor size
noise_level = 1e-4; % Amount of noise added to nonzero elements

%% Generate random dense tensor

G_true = tensor(randn(R_true));
A_true = cell(length(R_true),1);
for k = 1:length(R_true)
    A_true{k} = randn(I(k),R_true(k));
    [Qfac, ~] = qr(A_true{k}, 0);
    A_true{k} = Qfac;
end
X4 = tensor(ttensor(G_true, A_true)) + noise_level*randn(I);

fprintf('Generating data is done\n');

[core4, factors4] = DTucker(X4, [10 10 10 5], tol, maxiters, use_init);

Xr = ttm(tensor(core4), factors4);
our_error = norm(X4-Xr)^2/norm(tensor(X4))^2;
fprintf(' Error is  %4f\n', our_error);
