LASTN = maxNumCompThreads(1);


% Brainq data 
fprintf('Read brainq data\n');
path1 = './data/BRAINQ/BRAINQ.tensor';
X1 = import_data(path1);
X1 = tensor(X1);
fprintf('Reading brainq data is done\n');

[core1, factors1] = DTucker(X1, [10 10 5], 1e-4,50, 1);
Xr = ttm(tensor(core1), factors1);
our_error = norm(X1-Xr)^2/norm(tensor(X1))^2;
fprintf(' Error is  %4f\n', our_error);

% Boats data
fprintf('Read boats data\n');
X2 = tensor(double(load_boats()));
fprintf('Reading pancan data is done\n');

[core2, factors2] = DTucker(X2, [10 10 10], 1e-4, 50, 1);
Xr = ttm(tensor(core2), factors2);
our_error = norm(X2-Xr)^2/norm(tensor(X2))^2;
fprintf(' Error is  %4f\n', our_error);

% Air quality data
fprintf('Read air quality data\n');
path3 = './data/airquality/airquality.tsv';
X3 = import_data(path3);
X3 = tensor(X3);
fprintf('Reading air quality data is done\n');

[core3, factors3] = DTucker(X3, [10 10 5], 1e-4, 50, 1);

Xr = ttm(tensor(core3), factors3);
our_error = norm(X3-Xr)^2/norm(tensor(X3))^2;
fprintf(' Error is  %4f\n', our_error);

% HSI data
fprintf('Read HSI data\n');
X = cell([1 8]);
dims_tmp = zeros([8 3]);
for i=1:8
    path = './data/HSI/input/data';
    path = strcat(path, int2str(i), '.mat');
    tmp = load(path);
    X{1,i} =cell2mat(struct2cell(tmp));
    dims_tmp(i,:) = size(X{i});
end

maxlength = max(dims_tmp, [], 1);

for i = 1:8
    tmp_dims = size(X{i});
    for j =1:3
        curr_dims = tmp_dims(j);
        tmp_dims(j) = maxlength(j);
        add_dims = tmp_dims;
        add_dims(j) = tmp_dims(j)-curr_dims;
        X{i} = cat(j, X{i}, zeros(add_dims));
    end
end

X = cat(4, X{1}, X{2}, X{3}, X{4}, X{5}, X{6}, X{7}, X{8});

X = tensor(X);
fprintf('Reading HSI data is done\n');

[core4, factors4] = DTucker(X, [10 10 10 5], 1e-4, 50, 1);

Xr = ttm(tensor(core4), factors4);
our_error = norm(X-Xr)^2/norm(tensor(X))^2;
fprintf(' Error is  %4f\n', our_error);
