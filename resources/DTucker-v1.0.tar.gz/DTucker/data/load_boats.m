% load_boats:  load boat dataset
%
% Return
% X: gray scale videos of size (320, 240, 7000)
%

function X = load_boats()

path = './data/boats/input/in000001.jpg';
X = imread(path);  
X = rgb2gray(X);
for i=2:9
    path = './data/boats/input/in00000';
    path = strcat(path, int2str(i), '.jpg');
    tmp = imread(path);
    tmp = rgb2gray(tmp);
    X = cat(3, X, tmp);
end
for i=10:99
    path = './data/boats/input/in0000';
    path = strcat(path, int2str(i), '.jpg');
    tmp = imread(path);
    tmp = rgb2gray(tmp);
    X = cat(3, X, tmp);
end
for i=100:999
    path = './data/boats/input/in000';
    path = strcat(path, int2str(i), '.jpg');
    tmp = imread(path);
    tmp = rgb2gray(tmp);
    X = cat(3, X, tmp);
end
for i=1000:7000
    path = './data/boats/input/in00';
    path = strcat(path, int2str(i), '.jpg');
    tmp = imread(path);
    tmp = rgb2gray(tmp);
    X = cat(3, X, tmp);
end
end
