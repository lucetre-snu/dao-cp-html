% Ddecomp: Given a dense tensor, decompose slice matrices 
% using randomized singular value decomposition (svd)
% 
% Parameter
% X: input tensor which has dense form
% rank: target rank for svd
%
% Return
% decompU: the set of left singular vector matrices of sliced matrices computed by randomized svd
% decompS: the set of singular value matrices of sliced matrices computed by randomized svd
% decompV: the set of right singular vector matrices of sliced matrices computed by randomized svd
%

function [decompU, decompS, decompV] = Ddecomp(X, rank)
    dims = size(X)
    transform = dims(2)*ones(1, prod(dims(3:end)));
    X = double(tenmat(X, 1));
    decompU = cell(1, prod(dims(3:end)));
    decompS = cell(1, prod(dims(3:end)));
    decompV = cell(1, prod(dims(3:end)));


    for i=1:prod(dims(3:end))
        [u,s,v] = rSVD(X(:, ((i-1)*dims(2)+1):(i*dims(2))), rank);
        decompU{i} = u;
        decompS{i} = s;
        decompV{i} = v;
    end

end

